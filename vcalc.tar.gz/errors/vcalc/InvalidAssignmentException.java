package errors.vcalc;

public class InvalidAssignmentException extends Exception {

	public InvalidAssignmentException(String message) {
		super(message);
	}
}
