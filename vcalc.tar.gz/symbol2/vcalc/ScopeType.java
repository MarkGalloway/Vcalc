package symbol2.vcalc;

public enum ScopeType {
    GLOBAL,
    LOCAL;
}
