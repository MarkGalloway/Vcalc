package symbol2.vcalc;

public interface Type {
    public String getName();
}
